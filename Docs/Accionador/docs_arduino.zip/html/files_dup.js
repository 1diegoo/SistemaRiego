var files_dup =
[
    [ "dbg_utils.h", "dbg__utils_8h_source.html", null ],
    [ "funcs.h", "funcs_8h.html", "funcs_8h" ],
    [ "main.ino", "main_8ino.html", "main_8ino" ],
    [ "states.h", "states_8h.html", "states_8h" ]
];