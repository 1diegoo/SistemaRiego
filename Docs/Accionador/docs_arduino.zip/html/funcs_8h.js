var funcs_8h =
[
    [ "activateBomb", "funcs_8h.html#a4a8162388d336f2d58431ff52671b00d", null ],
    [ "connect", "funcs_8h.html#a0c2c69124d1f7408b409d4052fb4688c", null ],
    [ "readData", "funcs_8h.html#a24ce6dec934758600de80df80262dc17", null ],
    [ "sendReadings", "funcs_8h.html#a47668197b05c807c9de8bd57aba64561", null ],
    [ "setOnSleepMode", "funcs_8h.html#a061cbd968021c633901c8de3f0341e38", null ]
];