var main_8ino =
[
    [ "loop", "main_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "main_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ]
];