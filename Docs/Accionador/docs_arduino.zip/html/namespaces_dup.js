var namespaces_dup =
[
    [ "gbvars", "namespacegbvars.html", null ]
];