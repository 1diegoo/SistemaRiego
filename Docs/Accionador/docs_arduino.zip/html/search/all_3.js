var searchData=
[
  ['gbvars_0',['gbvars',['../namespacegbvars.html',1,'']]]
];
