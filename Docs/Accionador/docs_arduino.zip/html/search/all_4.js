var searchData=
[
  ['humedadaire_0',['humedadAire',['../struct_acc_info.html#a4fa367acd499c4a20a8c3baa1d960ede',1,'AccInfo']]],
  ['humedadsuelo_1',['humedadSuelo',['../struct_acc_info.html#a42d1d6eb9bdf6e2ebd28370f115fcde8',1,'AccInfo']]]
];
