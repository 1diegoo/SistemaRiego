var searchData=
[
  ['lecturas_0',['lecturas',['../states_8h.html#a59ba50ea038829521f1f678b7cc36ebc',1,'states.cpp']]],
  ['loop_1',['loop',['../main_8ino.html#afe461d27b9c48d5921c00d521181f12f',1,'main.ino']]],
  ['luminosidad_2',['luminosidad',['../struct_acc_info.html#a0c1c4c09be0c2c2ce7b4bca1e53da41b',1,'AccInfo']]]
];
