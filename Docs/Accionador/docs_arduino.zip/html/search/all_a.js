var searchData=
[
  ['temperatura_0',['temperatura',['../struct_acc_info.html#a6b6a22b04f441c034603710a1757183c',1,'AccInfo']]]
];
