var searchData=
[
  ['connect_0',['connect',['../funcs_8h.html#a0c2c69124d1f7408b409d4052fb4688c',1,'funcs.cpp']]]
];
