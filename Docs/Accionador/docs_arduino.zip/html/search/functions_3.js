var searchData=
[
  ['readdata_0',['readData',['../funcs_8h.html#a24ce6dec934758600de80df80262dc17',1,'funcs.cpp']]]
];
