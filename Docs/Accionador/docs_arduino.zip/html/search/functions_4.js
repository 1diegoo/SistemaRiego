var searchData=
[
  ['sendreadings_0',['sendReadings',['../funcs_8h.html#a47668197b05c807c9de8bd57aba64561',1,'funcs.cpp']]],
  ['setonsleepmode_1',['setOnSleepMode',['../funcs_8h.html#a061cbd968021c633901c8de3f0341e38',1,'funcs.cpp']]],
  ['setup_2',['setup',['../main_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'main.ino']]]
];
