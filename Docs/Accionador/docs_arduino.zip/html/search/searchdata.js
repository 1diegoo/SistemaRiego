var indexSectionsWithContent =
{
  0: "acfghlmprstw",
  1: "a",
  2: "g",
  3: "fms",
  4: "aclrs",
  5: "chlpt",
  6: "s",
  7: "arsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Espacios de nombres",
  3: "Archivos",
  4: "Funciones",
  5: "Variables",
  6: "Enumeraciones",
  7: "Valores de enumeraciones"
};

