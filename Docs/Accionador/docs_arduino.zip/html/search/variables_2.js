var searchData=
[
  ['lecturas_0',['lecturas',['../states_8h.html#a59ba50ea038829521f1f678b7cc36ebc',1,'states.cpp']]],
  ['luminosidad_1',['luminosidad',['../struct_acc_info.html#a0c1c4c09be0c2c2ce7b4bca1e53da41b',1,'AccInfo']]]
];
