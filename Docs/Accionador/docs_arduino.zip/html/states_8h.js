var states_8h =
[
    [ "AccInfo", "struct_acc_info.html", "struct_acc_info" ],
    [ "states", "states_8h.html#a3aa14ec0386405e1fc56920a2e32c8de", [
      [ "searching", "states_8h.html#a3aa14ec0386405e1fc56920a2e32c8dea9cf0fad66f27ca22b7ee721d5413ea62", null ],
      [ "reading", "states_8h.html#a3aa14ec0386405e1fc56920a2e32c8deaeceadc1d40cea061fd5986f2a109ee93", null ],
      [ "sending", "states_8h.html#a3aa14ec0386405e1fc56920a2e32c8dea80f5f164aa43626d4045163a4ae593b5", null ],
      [ "waiting", "states_8h.html#a3aa14ec0386405e1fc56920a2e32c8deacb05cab65afefab8fd3831d92cfc68be", null ],
      [ "active", "states_8h.html#a3aa14ec0386405e1fc56920a2e32c8deac76a5e84e4bdee527e274ea30c680d79", null ]
    ] ],
    [ "current_state", "states_8h.html#a3de2bb661e0711507cf5173bf6477d40", null ],
    [ "lecturas", "states_8h.html#a59ba50ea038829521f1f678b7cc36ebc", null ],
    [ "pinBomba", "states_8h.html#a139c80a598a4b012b144fb4f5cff5fc3", null ]
];