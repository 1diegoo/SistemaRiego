var struct_acc_info =
[
    [ "humedadAire", "struct_acc_info.html#a4fa367acd499c4a20a8c3baa1d960ede", null ],
    [ "humedadSuelo", "struct_acc_info.html#a42d1d6eb9bdf6e2ebd28370f115fcde8", null ],
    [ "luminosidad", "struct_acc_info.html#a0c1c4c09be0c2c2ce7b4bca1e53da41b", null ],
    [ "temperatura", "struct_acc_info.html#a6b6a22b04f441c034603710a1757183c", null ]
];